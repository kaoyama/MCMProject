//
//  historyDetailViewController.h
//  Customer
//
//  Created by Blayne Kennedy on 2/26/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface historyDetailViewController : UIViewController

//@property (nonatomic, strong) IBOutlet UILabel *selectLabel;
@property (nonatomic, strong) NSString *selectName;
@property (nonatomic, strong) NSString *selectIndexNum;
@property (nonatomic, strong) NSString *userName;
@property (weak, nonatomic) IBOutlet UILabel *merchant;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *paid;
@property (weak, nonatomic) IBOutlet UILabel *cost;

@end
