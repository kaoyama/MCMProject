//
//  MyAnnotation.m
//  Customer
//
//  Created by Blayne Kennedy on 2/17/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "MyAnnotation.h"


@implementation MyAnnotation

@synthesize title;
@synthesize subtitle;
@synthesize coordinate;

- (void)dealloc
{
    self.title = nil;
    self.subtitle = nil;
}
@end
