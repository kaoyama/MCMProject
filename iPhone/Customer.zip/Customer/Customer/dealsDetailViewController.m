//
//  dealsDetailViewController.m
//  Customer
//
//  Created by Blayne Kennedy on 3/5/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "dealsDetailViewController.h"
#import "JSONKit.h"

@interface dealsDetailViewController ()

@end

@implementation dealsDetailViewController{
    
    NSMutableArray *deals;
    NSMutableArray *indexNumber;
}

@synthesize title;
@synthesize content;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPGetDealsForCustomers.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
    [nameElements setObject:_userName forKey:@"userName"];
    
    NSString *jsonString = [nameElements JSONString];
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request setHTTPBody:data];
    
    NSURLResponse *response;
    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    for (NSDictionary *person in simpleDictionary) {
        
        if ([_selectIndexNum isEqualToString:[person objectForKey:@"dealIndex"]]) {
            
            _merchantLabel.text = [person objectForKey:@"merchant"];
            title.text = [person objectForKey:@"title"];
            content.text = [person objectForKey:@"content"];
            
        }
        
        [deals addObject:[person objectForKey:@"merchant"]];
        [indexNumber addObject:[person objectForKey:@"dealIndex"]];
        
    }
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setTitle:nil];
    [self setContent:nil];
    [self setMerchantLabel:nil];
    [super viewDidUnload];
}
@end
