var searchData=
[
  ['conversionresult',['ConversionResult',['../_j_s_o_n_kit_8m.html#afa2a6d5a1431289c92cea9cceeb174c9',1,'JSONKit.m']]]
];
