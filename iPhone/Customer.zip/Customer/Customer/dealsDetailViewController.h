//
//  dealsDetailViewController.h
//  Customer
//
//  Created by Blayne Kennedy on 3/5/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface dealsDetailViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (nonatomic, strong) NSString *selectIndexNum;
@property (nonatomic, strong) NSString *userName;
@property (weak, nonatomic) IBOutlet UILabel *merchantLabel;

@end
