var searchData=
[
  ['homeviewcontroller',['homeViewController',['../interfacehome_view_controller.html',1,'']]],
  ['homeviewcontroller_28_29',['homeViewController()',['../categoryhome_view_controller_07_08.html',1,'']]]
];
