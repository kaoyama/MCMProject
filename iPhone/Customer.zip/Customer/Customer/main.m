//
//  main.m
//  fckRestKit
//
//  Created by Kim on 1/31/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "capstoneAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([capstoneAppDelegate class]));
    }
}
