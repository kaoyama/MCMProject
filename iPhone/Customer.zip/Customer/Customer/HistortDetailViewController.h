//
//  HistortDetailViewController.h
//  Customer
//
//  Created by Blayne Kennedy on 2/24/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistortDetailViewController : UITableViewController

@property (nonatomic, strong) IBOutlet UILabel *recipeLabel;
@property (nonatomic, strong) NSString *recipeName;

@end
