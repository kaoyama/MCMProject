var searchData=
[
  ['username',['userName',['../interface_near_view_controller.html#ac38202c6f4861ad216f9fbc5d962b5ab',1,'NearViewController']]],
  ['usertext',['userText',['../categorylogin_view_controller_07_08.html#a5cbfeeae6492f16fbaabb4de5dd5b582',1,'loginViewController()::userText()'],['../categoryregister_view_controller_07_08.html#a5cbfeeae6492f16fbaabb4de5dd5b582',1,'registerViewController()::userText()']]]
];
