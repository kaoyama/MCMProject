//
//  dealsViewController.h
//  Customer
//
//  Created by Blayne Kennedy on 3/5/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface dealsViewController : UITableViewController

@property (nonatomic, strong) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSString *userName;
@property (weak, nonatomic) IBOutlet UILabel *noDeals;

@end
