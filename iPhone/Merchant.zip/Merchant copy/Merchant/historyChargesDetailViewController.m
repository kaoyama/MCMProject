//
//  historyChargesDetailViewController.m
//  Merchant
//
//  Created by Blayne Kennedy on 3/31/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "historyChargesDetailViewController.h"
#import "JSONKit.h"

@interface historyChargesDetailViewController ()

@end

@implementation historyChargesDetailViewController{
    
    NSMutableArray *pendingCharges;
    NSMutableArray *indexNumber;
}

@synthesize customer;
@synthesize time;
@synthesize paid;
@synthesize cost;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    pendingCharges = [[NSMutableArray alloc] init];
    indexNumber = [[NSMutableArray alloc] init];
    
    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPGetMerchantTransactions.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
    [nameElements setObject:_userName forKey:@"merchant"];
    
    NSString *jsonString = [nameElements JSONString];
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request setHTTPBody:data];
    
    NSURLResponse *response;
    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    
    for (NSDictionary *person in simpleDictionary) {
        
        if ([_selectIndexNum isEqualToString:[person objectForKey:@"transactionIndex"]]) {
            
            customer.text = [person objectForKey:@"customer"];
            time.text = [person objectForKey:@"purchaseTime"];
            cost.text = [person objectForKey:@"cost"];
            
            if ([@"1" isEqualToString:[person objectForKey:@"cancelled"]]){
                
                paid.text = @"Cancelled";
                
            }
            else{
                paid.text = @"Paid";
            }
        }
        
        [pendingCharges addObject:[person objectForKey:@"customer"]];
        [indexNumber addObject:[person objectForKey:@"transactionIndex"]];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setCustomer:nil];
    [self setTime:nil];
    [self setPaid:nil];
    [self setCost:nil];
    [super viewDidUnload];
}

@end

