var searchData=
[
  ['unsignedlonglongvalue',['unsignedLongLongValue',['../struct_j_k_token_value.html#a5e85a65fef51595922a1e0904c7ab4d5',1,'JKTokenValue']]],
  ['utf8conversionbuffer',['utf8ConversionBuffer',['../struct_j_k_encode_state.html#ad6003bab238ff8338f46d45fc4cfbcbd',1,'JKEncodeState']]]
];
