//
//  historyChargesDetailViewController.h
//  Merchant
//
//  Created by Blayne Kennedy on 3/31/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface historyChargesDetailViewController : UIViewController

@property (nonatomic, strong) NSString *selectIndexNum;
@property (nonatomic, strong) NSString *userName;
@property (weak, nonatomic) IBOutlet UILabel *customer;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *paid;
@property (weak, nonatomic) IBOutlet UILabel *cost;

@end
