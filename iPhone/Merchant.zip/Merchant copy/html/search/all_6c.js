var searchData=
[
  ['loginviewcontroller',['loginViewController',['../interfacelogin_view_controller.html',1,'']]],
  ['loginviewcontroller_28_29',['loginViewController()',['../categorylogin_view_controller_07_08.html',1,'']]]
];
