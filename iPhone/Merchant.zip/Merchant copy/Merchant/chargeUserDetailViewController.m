//
//  chargeUserDetailViewController.m
//  Merchant
//
//  Created by Blayne Kennedy on 2/26/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "chargeUserDetailViewController.h"
#import "JSONKit.h"

@interface chargeUserDetailViewController ()

@property (weak, nonatomic) IBOutlet UITextField *chargeField;
@property (weak, nonatomic) IBOutlet UILabel *totalField;
@property (weak, nonatomic) IBOutlet UILabel *taxField;


@end

@implementation chargeUserDetailViewController

@synthesize userLabel;
@synthesize userName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    userLabel.text = _selectName;

    [_chargeField becomeFirstResponder];
    
    [_chargeField addTarget:self action:@selector(textViewDidChange:) forControlEvents:UIControlEventEditingChanged];
    
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload
{
    [self setChargeField:nil];
    [self setTotalField:nil];
    [self setTaxField:nil];
    [super viewDidUnload];
}

- (IBAction)chargeButtonPressed:(id)sender
{
    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPAddUserTransaction.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
    [nameElements setObject:userName forKey:@"merchant"];
    [nameElements setObject:_selectName forKey:@"customer"];
    [nameElements setObject:_totalField.text forKey:@"cost"];
    
    NSString *jsonString = [nameElements JSONString];
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request setHTTPBody:data];
    
    NSURLResponse *response;
    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements    
    for (NSDictionary *person in simpleDictionary) {
                NSLog(@"Charge good");
    }
    
    
    NSString *Msg = (@"has been charged $");
    NSString *currentCharge = _totalField.text;
    NSString *alertMsg = [NSString stringWithFormat:@"%@ %@ %@",_selectName,Msg,currentCharge];
    
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Charge Complete"
                                                    message:alertMsg
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)textViewDidChange:(UITextView *)textView {
    
    CGFloat inputAmount = [_chargeField.text floatValue];
    CGFloat taxAmount = inputAmount * .07;
    CGFloat totalAmount = inputAmount + taxAmount;
    _taxField.text = [NSString stringWithFormat:@"%.2f",taxAmount];
    _totalField.text = [NSString stringWithFormat:@"%.2f",totalAmount];

}

@end
