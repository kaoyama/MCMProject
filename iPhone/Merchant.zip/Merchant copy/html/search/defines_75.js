var searchData=
[
  ['uni_5fmax_5fbmp',['UNI_MAX_BMP',['../_j_s_o_n_kit_8m.html#adc71280d09832f0fb6c6b83fbf043140',1,'JSONKit.m']]],
  ['uni_5fmax_5flegal_5futf32',['UNI_MAX_LEGAL_UTF32',['../_j_s_o_n_kit_8m.html#a98a2f50a1ca513613316ffd384dd1bfb',1,'JSONKit.m']]],
  ['uni_5fmax_5futf16',['UNI_MAX_UTF16',['../_j_s_o_n_kit_8m.html#a69d0ea77d1231214ba0893e846d7fcaf',1,'JSONKit.m']]],
  ['uni_5fmax_5futf32',['UNI_MAX_UTF32',['../_j_s_o_n_kit_8m.html#a26c4390ae1463df1e6075ea585ed79a3',1,'JSONKit.m']]],
  ['uni_5freplacement_5fchar',['UNI_REPLACEMENT_CHAR',['../_j_s_o_n_kit_8m.html#a44b240b95a93f71535c03f5e26d7dbe1',1,'JSONKit.m']]],
  ['uni_5fsur_5fhigh_5fend',['UNI_SUR_HIGH_END',['../_j_s_o_n_kit_8m.html#ae5481872f1061e4e2a66849802b4b81e',1,'JSONKit.m']]],
  ['uni_5fsur_5fhigh_5fstart',['UNI_SUR_HIGH_START',['../_j_s_o_n_kit_8m.html#a4ab84eb26356a90f3b7b9ac7aca1edfe',1,'JSONKit.m']]],
  ['uni_5fsur_5flow_5fend',['UNI_SUR_LOW_END',['../_j_s_o_n_kit_8m.html#ab9a531ffb73be79f7089049c1b84dc59',1,'JSONKit.m']]],
  ['uni_5fsur_5flow_5fstart',['UNI_SUR_LOW_START',['../_j_s_o_n_kit_8m.html#a23de5862375b48afcb4e3ff7b56a274d',1,'JSONKit.m']]]
];
