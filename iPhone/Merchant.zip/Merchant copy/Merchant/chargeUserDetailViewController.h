//
//  chargeUserDetailViewController.h
//  Merchant
//
//  Created by Blayne Kennedy on 2/26/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface chargeUserDetailViewController : UIViewController

@property (nonatomic, strong) IBOutlet UILabel *userLabel;
@property (nonatomic, strong) NSString *userName;
@property (nonatomic, strong) NSString *selectName;

@end
