var searchData=
[
  ['tableview',['tableView',['../interface_near_view_controller.html#a0eda8ceb83861639e0ee31b816a175c4',1,'NearViewController']]]
];
