var searchData=
[
  ['registerviewcontroller',['registerViewController',['../interfaceregister_view_controller.html',1,'']]],
  ['registerviewcontroller_28_29',['registerViewController()',['../categoryregister_view_controller_07_08.html',1,'']]]
];
