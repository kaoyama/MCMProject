var searchData=
[
  ['nearviewcontroller_2eh',['NearViewController.h',['../_near_view_controller_8h.html',1,'']]],
  ['nearviewcontroller_2em',['NearViewController.m',['../_near_view_controller_8m.html',1,'']]]
];
