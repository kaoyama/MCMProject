//
//  historyDetailViewController.h
//  Customer
//
//  Created by Blayne Kennedy on 2/26/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface historyDetailViewController : UITableViewController

@property (nonatomic, strong) IBOutlet UILabel *recipeLabel;
@property (nonatomic, strong) NSString *recipeName;

@end
