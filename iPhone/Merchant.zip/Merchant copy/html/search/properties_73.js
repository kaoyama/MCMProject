var searchData=
[
  ['selectname',['selectName',['../interfacehome_view_controller.html#a5d93750aaa2a5f349a310130729a194a',1,'homeViewController']]]
];
