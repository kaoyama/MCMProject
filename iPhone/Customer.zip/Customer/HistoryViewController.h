//
//  HistoryViewController.h
//  Customer
//
//  Created by Blayne Kennedy on 2/24/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryViewController : UITableViewController

@property (nonatomic, strong) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSString *selectName;
@property (nonatomic, strong) NSString *userName;
@property (weak, nonatomic) IBOutlet UILabel *noHistory;


@end
