var searchData=
[
  ['initwithjkdictionary_3a',['initWithJKDictionary:',['../interface_j_k_dictionary_enumerator.html#a5498b1645dccafb95c3573967f145b44',1,'JKDictionaryEnumerator']]],
  ['isvalidcodepoint',['isValidCodePoint',['../_j_s_o_n_kit_8m.html#acdf6e62363e082be5d7789b46446739e',1,'JSONKit.m']]]
];
