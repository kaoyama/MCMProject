//
//  loginViewController.m
//  Merchant
//
//  Created by Blayne Kennedy on 2/5/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "loginViewController.h"
#import "homeViewController.h"
#import "JSONKit.h"

@interface loginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userText;
@property (weak, nonatomic) IBOutlet UITextField *passwordText;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;


@end

@implementation loginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.userText setReturnKeyType:UIReturnKeyDone];
    self.userText.delegate = self;
    [self.passwordText setReturnKeyType:UIReturnKeyDone];
    self.passwordText.delegate = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload
{
    [self setUserText:nil];
    [self setPasswordText:nil];
    [self setLoginButton:nil];
    [super viewDidUnload];
}
- (IBAction)LoginButtonClicked:(id)sender
{
    
    NSString *userTestBox = self.userText.text;
    NSString *passwordTextBox = self.passwordText.text;
    
    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPValidateLogin.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
    [nameElements setObject:userTestBox forKey:@"userName"];
    [nameElements setObject:passwordTextBox forKey:@"pwd"];
    [nameElements setObject:@"0" forKey:@"merchant"];
    
    NSString *jsonString = [nameElements JSONString];
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request setHTTPBody:data];
    
    NSURLResponse *response;
    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    for (NSDictionary *person in simpleDictionary) {
        int loginNum = [[person objectForKey:@"result"] integerValue];
        
        if(loginNum == 0){//login bad
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:userTestBox
                                                            message:@"Username or password is wrong."
                                                           delegate:nil
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
            
        }
        if(loginNum == 1){//login good
            
            [self performSegueWithIdentifier:@"loginHome" sender:sender];
            _userText.text = @"";
            _passwordText.text = @"";
            
        }
        
        else{//something really bad happened
            NSLog(@"The database returned something other then a 1 or 0");
        }
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"loginHome"]) {
        homeViewController *destViewController = segue.destinationViewController;
        destViewController.selectName = _userText.text;
    }
}



@end
