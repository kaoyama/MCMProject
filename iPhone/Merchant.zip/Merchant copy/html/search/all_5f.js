var searchData=
[
  ['_5f_5fhas_5ffeature',['__has_feature',['../_j_s_o_n_kit_8m.html#af989845e24678c452b9222afdac95e7f',1,'JSONKit.m']]],
  ['_5fjsonkit_5fh_5f',['_JSONKIT_H_',['../_j_s_o_n_kit_8h.html#a63229b0aaaf1ef486abfccc1a14f8b05',1,'JSONKit.h']]]
];
