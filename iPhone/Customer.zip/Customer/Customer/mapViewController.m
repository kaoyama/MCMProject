//
//  mapViewController.m
//  Customer
//
//  Created by Blayne Kennedy on 2/5/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "mapViewController.h"
#import "MyAnnotation.h"
#import <CoreLocation/CoreLocation.h>
#import "JSONKit.h"

@interface mapViewController ()

@end

@implementation mapViewController
@synthesize mapView;

CLLocationManager *locationManager;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.mapView.delegate = self;    
    
    locationManager = [[CLLocationManager alloc] init];//gets lat and long of user
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    [locationManager startUpdatingLocation];
    
    float latitude = locationManager.location.coordinate.latitude;
    float longitude = locationManager.location.coordinate.longitude;
    
    NSLog(@"Latitude %f.", latitude);
    NSLog(@"Longitude %f.", longitude);
    
    int latitudeInt = latitude * 1000000;
    int longitudeInt = longitude * 1000000;
    
    NSLog(@"Latitude %d.", latitudeInt);
    NSLog(@"Longitude %d.", longitudeInt);
    
    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPGetNearbyMerchants.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
    [nameElements setObject:_userName forKey:@"userName"];
    
    NSString *jsonString = [nameElements JSONString];
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request setHTTPBody:data];
    
    NSURLResponse *response;
    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    for (NSDictionary *person in simpleDictionary) {//adds pins to the map based on the data parsed from "theReply"
        
        float lat = [[person objectForKey:@"latitude"] integerValue] / 1000000.0;
        float log = [[person objectForKey:@"longitude"] integerValue] / 1000000.0;
        NSString *marcName = [person objectForKey:@"merchantUserName"];
        
        NSMutableArray* annotations=[[NSMutableArray alloc] init];
        CLLocationCoordinate2D theCoordinate10;
        theCoordinate10.latitude = lat;
        theCoordinate10.longitude = log;
        
        MyAnnotation* myAnnotation10=[[MyAnnotation alloc] init];
        myAnnotation10.coordinate=theCoordinate10;
        myAnnotation10.title=marcName;
        myAnnotation10.subtitle=@"in the city";
        
        [mapView addAnnotation:myAnnotation10];
        
        [annotations addObject:myAnnotation10];
    }    
    
    NSURL *url2 = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPGetTargetedDealsForCustomers.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements2 = [NSMutableDictionary dictionary];
    [nameElements2 setObject:_userName forKey:@"userName"];
    
    NSString *jsonString2 = [nameElements2 JSONString];
    NSData *data2 = [jsonString2 dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength2 = [NSString stringWithFormat:@"%d", [data2 length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request2 = [NSMutableURLRequest requestWithURL:url2];
    [request2 setHTTPMethod:@"POST"];
    [request2 setValue:postLength2 forHTTPHeaderField:@"Content-Length"];
    [request2 setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request2 setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request2 setHTTPBody:data2];
    
    NSURLResponse *response2;
    NSData *GETReply2 = [NSURLConnection sendSynchronousRequest:request2 returningResponse:&response2 error:nil];
    NSString *theReply2 = [[NSString alloc] initWithBytes:[GETReply2 bytes] length:[GETReply2 length] encoding: NSASCIIStringEncoding];
    NSLog(@"Reply2: %@", theReply2);
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder2 = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary2 = [decoder2 objectWithData:[theReply2 dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    NSLog(@"Individual JSON elements:");
    
    for (NSDictionary *person in simpleDictionary2) {        
        
    }
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation//zooms to where the user is
{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 400, 400);
    [self.mapView setRegion:[self.mapView regionThatFits:region] animated:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)UpdateLocation:(id)sender {
    
    locationManager = [[CLLocationManager alloc] init];//gets lat and long of user
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    [locationManager startUpdatingLocation];
    
    float latitude = locationManager.location.coordinate.latitude;
    float longitude = locationManager.location.coordinate.longitude;
    
    NSLog(@"Latitude %f.", latitude);
    NSLog(@"Longitude %f.", longitude);
    
    int latitudeInt = latitude * 1000000;
    int longitudeInt = longitude * 1000000;
    
    NSLog(@"Latitude %d.", latitudeInt);
    NSLog(@"Longitude %d.", longitudeInt);
    
    NSString *latitudeString = [NSString stringWithFormat:@"%d",latitudeInt];
    NSString *longitudeString = [NSString stringWithFormat:@"%d",longitudeInt];
    
    NSLog(@"latitudeString %@",latitudeString);
    NSLog(@"longitudeString %@",longitudeString);
    
    NSLog(@"username %@",_userName);
    
    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~kd268/PHPUpdateUserLocation.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
    
    [nameElements setObject:_userName forKey:@"userName"];
    [nameElements setObject:latitudeString forKey:@"latitude"];
    [nameElements setObject:longitudeString forKey:@"longitude"];
    
    NSString *jsonString = [nameElements JSONString];
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request setHTTPBody:data];
    
    NSURLResponse *response;
    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    
    for (NSDictionary *person in simpleDictionary) {
        
    }
    
    NSURL *url2 = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPGetTargetedDealsForCustomers.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements2 = [NSMutableDictionary dictionary];
    [nameElements2 setObject:_userName forKey:@"userName"];
    
    NSString *jsonString2 = [nameElements2 JSONString];
    NSData *data2 = [jsonString2 dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength2 = [NSString stringWithFormat:@"%d", [data2 length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request2 = [NSMutableURLRequest requestWithURL:url2];
    [request2 setHTTPMethod:@"POST"];
    [request2 setValue:postLength2 forHTTPHeaderField:@"Content-Length"];
    [request2 setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request2 setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request2 setHTTPBody:data2];
    
    NSURLResponse *response2;
    NSData *GETReply2 = [NSURLConnection sendSynchronousRequest:request2 returningResponse:&response2 error:nil];
    NSString *theReply2 = [[NSString alloc] initWithBytes:[GETReply2 bytes] length:[GETReply2 length] encoding: NSASCIIStringEncoding];
    NSLog(@"Reply2: %@", theReply2);
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder2 = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary2 = [decoder2 objectWithData:[theReply2 dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    NSLog(@"Individual JSON elements:");
    
    for (NSDictionary *person in simpleDictionary2) {
    
    }
}

//**************************************
//Used for testing, test press will create a lat long pop up message, and resetPress will set the users cords to 0.
//**************************************

- (IBAction)testPress:(id)sender {
    
    locationManager = [[CLLocationManager alloc] init];//gets lat and long of user
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    [locationManager startUpdatingLocation];
    
    float latitude = locationManager.location.coordinate.latitude;
    float longitude = locationManager.location.coordinate.longitude;
    
    NSLog(@"Latitude %f.", latitude);
    NSLog(@"Longitude %f.", longitude);
    
    int latitudeInt = latitude * 1000000;
    int longitudeInt = longitude * 1000000;
    
    NSLog(@"Latitude %d.", latitudeInt);
    NSLog(@"Longitude %d.", longitudeInt);
    
    NSString *alertMsg = [NSString stringWithFormat:@"Latitude %f Longitude %f",latitude,longitude];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Loc"
                                                    message:alertMsg
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    
}

- (IBAction)resetPress:(id)sender {
    
    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~kd268/PHPUpdateUserLocation.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
    
    [nameElements setObject:_userName forKey:@"userName"];
    [nameElements setObject:@"0" forKey:@"latitude"];
    [nameElements setObject:@"0" forKey:@"longitude"];
    
    NSString *jsonString = [nameElements JSONString];
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request setHTTPBody:data];
    
    NSURLResponse *response;
    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    for (NSDictionary *person in simpleDictionary) {
        
    }
}

@end
