var searchData=
[
  ['roundsizeuptomultipleof',['roundSizeUpToMultipleOf',['../struct_j_k_managed_buffer.html#a931b05c6b4b87888d703d424e4595b15',1,'JKManagedBuffer::roundSizeUpToMultipleOf()'],['../struct_j_k_object_stack.html#a931b05c6b4b87888d703d424e4595b15',1,'JKObjectStack::roundSizeUpToMultipleOf()']]]
];
