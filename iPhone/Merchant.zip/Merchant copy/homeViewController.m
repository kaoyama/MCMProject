//
//  homeViewController.m
//  Merchant
//
//  Created by Blayne Kennedy on 2/5/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "homeViewController.h"
#import "NearViewController.h"
#import "mapViewController.h"
#import "pendingChargesViewController.h"
#import "historyChargesViewController.h"

@interface homeViewController ()

@end

@implementation homeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.hidesBackButton = TRUE;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)logOutButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"homeNear"]) {
        NearViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
    if ([segue.identifier isEqualToString:@"homeDeal"]) {
        NearViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
    if ([segue.identifier isEqualToString:@"homeMap"]) {
        mapViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
    if ([segue.identifier isEqualToString:@"homePending"]) {
        pendingChargesViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
    if ([segue.identifier isEqualToString:@"homeHistory"]) {
        historyChargesViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
}

@end
