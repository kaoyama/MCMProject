//
//  pendingChargesViewController.m
//  Customer
//
//  Created by Blayne Kennedy on 2/28/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "pendingChargesViewController.h"
#import "pendingChargesDetailViewController.h"
#import "JSONKit.h"

@interface pendingChargesViewController ()

@end

@implementation pendingChargesViewController {
    NSMutableArray *deals;
    NSMutableArray *indexNumber;
}

@synthesize tableView;


- (void)viewDidLoad
{
    [super viewDidLoad];
//    // Initialize table data
//    
//    deals = [[NSMutableArray alloc] init];
//    indexNumber = [[NSMutableArray alloc] init];
//    
//    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPGetUserTransactions.php"];
//    
//    //*******************************
//    // Put JSON Object
//    //*******************************
//    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
//    [nameElements setObject:_userName forKey:@"userName"];
//    
//    NSString *jsonString = [nameElements JSONString];
//    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
//    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
//    
//    //*********************************
//    // Send HTTP Request and get Reply
//    //*********************************
//    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
//    [request setHTTPMethod:@"POST"];
//    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
//    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
//    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
//    [request setHTTPBody:data];
//    
//    NSURLResponse *response;
//    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
//    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
//    //NSLog(@"Reply: %@", theReply);
//    
//    //*********************************
//    // Parse received JSON object
//    //*********************************
//    
//    // Initialize JSON decoder from JSONKit.h
//    JSONDecoder* decoder = [[JSONDecoder alloc] init];
//    
//    // Encode JSON string to NSDictionary
//    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
//    
//    // Parse JSON elements
//    
//    for (NSDictionary *person in simpleDictionary) {//adds pins to the map based on the data parsed from "theReply"
//        
//        if ([@"0" isEqualToString:[person objectForKey:@"paid"]]&&[@"0" isEqualToString:[person objectForKey:@"cancelled"]]) {
//        
//            [deals addObject:[person objectForKey:@"merchant"]];
//            [indexNumber addObject:[person objectForKey:@"transactionIndex"]];
//        }
//    }
}


- (void)viewDidUnload
{
    [self setNoCharges:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [indexNumber count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"PendingCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    cell.textLabel.text = [deals objectAtIndex:indexPath.row];
    return cell;
}

-(void)viewWillAppear:(BOOL)animated {
    
    [super viewDidLoad];
    // Initialize table data
    
    deals = [[NSMutableArray alloc] init];
    indexNumber = [[NSMutableArray alloc] init];
    
    NSURL *url = [NSURL URLWithString:@"http://dana.ucc.nau.edu/~cs854/PHPGetUserTransactions.php"];
    
    //*******************************
    // Put JSON Object
    //*******************************
    NSMutableDictionary *nameElements = [NSMutableDictionary dictionary];
    [nameElements setObject:_userName forKey:@"userName"];
    
    NSString *jsonString = [nameElements JSONString];
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSString *postLength = [NSString stringWithFormat:@"%d", [data length]];
    
    //*********************************
    // Send HTTP Request and get Reply
    //*********************************
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setCachePolicy:NSURLRequestReloadIgnoringCacheData];
    [request setHTTPBody:data];
    
    NSURLResponse *response;
    NSData *GETReply = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSString *theReply = [[NSString alloc] initWithBytes:[GETReply bytes] length:[GETReply length] encoding: NSASCIIStringEncoding];
    
    //*********************************
    // Parse received JSON object
    //*********************************
    
    // Initialize JSON decoder from JSONKit.h
    JSONDecoder* decoder = [[JSONDecoder alloc] init];
    
    // Encode JSON string to NSDictionary
    NSDictionary *simpleDictionary = [decoder objectWithData:[theReply dataUsingEncoding:NSUTF8StringEncoding]];
    
    // Parse JSON elements
    
    for (NSDictionary *person in simpleDictionary) {
        
        if ([@"0" isEqualToString:[person objectForKey:@"paid"]]&&[@"0" isEqualToString:[person objectForKey:@"cancelled"]]) {
            
            [indexNumber addObject:[person objectForKey:@"transactionIndex"]];
            
            NSString *customerCell = [person objectForKey:@"merchant"];
            NSString *costCell = [person objectForKey:@"cost"];
            NSString *spaceCell = @" $";
            
            NSString * addCell = [NSString stringWithFormat:@"%@%@%@", customerCell,spaceCell ,costCell];
            
            [deals addObject:(addCell)];
        }
        
    }
    
    [self.tableView reloadData];

    if ([deals  count]==0){
    
        _noCharges.text = @"No Pending Charges";
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"pendingDetail"]) {
        
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        pendingChargesDetailViewController *destViewController = segue.destinationViewController;
        destViewController.selectIndexNum = [indexNumber objectAtIndex:indexPath.row];
        destViewController.userName = _userName;
    }
}

@end