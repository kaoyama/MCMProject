var searchData=
[
  ['nsinteger_5fdefined',['NSINTEGER_DEFINED',['../_j_s_o_n_kit_8h.html#a644b3923ec31cfd9c9b7bdac5b0b975f',1,'JSONKit.h']]],
  ['nsintegermax',['NSIntegerMax',['../_j_s_o_n_kit_8h.html#a162afc5b4860b2e07699e32b1ee7f8e8',1,'JSONKit.h']]],
  ['nsintegermin',['NSIntegerMin',['../_j_s_o_n_kit_8h.html#ac45f211be6b784535439e20efcf7b40c',1,'JSONKit.h']]],
  ['nsuintegermax',['NSUIntegerMax',['../_j_s_o_n_kit_8h.html#af0fd383cb63174ce95af12a483994abd',1,'JSONKit.h']]]
];
