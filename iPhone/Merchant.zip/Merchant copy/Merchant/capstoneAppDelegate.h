//
//  capstoneAppDelegate.h
//  Merchant
//
//  Created by Kim on 1/31/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface capstoneAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
