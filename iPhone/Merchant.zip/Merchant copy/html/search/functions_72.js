var searchData=
[
  ['releasestate',['releaseState',['../interface_j_k_serializer.html#a64763abf0d1a7a31058f4be44f6fb9cd',1,'JKSerializer']]]
];
