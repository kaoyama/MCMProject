var searchData=
[
  ['conversionok',['conversionOK',['../_j_s_o_n_kit_8m.html#afa2a6d5a1431289c92cea9cceeb174c9a52ace604d4b4bfdbb02699abcdfc5856',1,'JSONKit.m']]]
];
