//
//  homeViewController.m
//  Customer
//
//  Created by Blayne Kennedy on 2/5/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import "homeViewController.h"
#import "pendingChargesViewController.h"
#import "HistoryViewController.h"
#import "dealsViewController.h"
#import "mapViewController.h"

@interface homeViewController ()

@end

@implementation homeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.hidesBackButton = TRUE;
    
    NSLog(@"Home Username: %@",_selectName);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)logOutButton:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"homePendingCharges"]) {
        pendingChargesViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
    if ([segue.identifier isEqualToString:@"homeHistory"]) {
        HistoryViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
    if ([segue.identifier isEqualToString:@"homeDeals"]) {
        dealsViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
    if ([segue.identifier isEqualToString:@"homeMap"]) {
        mapViewController *destViewController = segue.destinationViewController;
        destViewController.userName = _selectName;
    }
}



@end
