//
//  registerViewController.h
//  Customer
//
//  Created by Blayne Kennedy on 2/5/13.
//  Copyright (c) 2013 Kim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface registerViewController : UIViewController

@end
